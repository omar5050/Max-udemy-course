import { Component } from '@angular/core';

@Component({
  selector: 'app-warning-alert',
  templateUrl: './warning-alert.compoent.html',
  styleUrls: ['./warning-alert.component.css'],
})
export class WarningAlert {}
